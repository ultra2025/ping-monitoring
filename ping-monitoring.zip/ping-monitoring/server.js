const express = require("express");
const axios = require("axios");
const ping = require("ping");
const path = require("path");

const app = express();
const PORT = 3000;

app.use(express.static("public"));

app.get("/api/ping", async (req, res) => {
  const host = req.query.host;
  if (!host) return res.status(400).json({ error: "Host is required" });

  try {
    const result = await ping.promise.probe(host);
    res.json({ host, alive: result.alive, time: result.time });
  } catch (err) {
    res.status(500).json({ error: "Ping gagal" });
  }
});

app.get("/api/superping", async (req, res) => {
  const host = req.query.host;
  if (!host) return res.status(400).json({ error: "Host is required" });

  try {
    const response = await axios.get(`https://api.superping.io/status?host=${host}`, {
      headers: {
        apikey: "ur2987389-289ddd16f853f9fdf8b57887"
      }
    });

    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: "Gagal mengambil data dari SuperPing API" });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Server berjalan di http://localhost:${PORT}`);
});
