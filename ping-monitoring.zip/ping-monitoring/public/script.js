function pingHost() {
  const host = document.getElementById("hostInput").value;
  const resultDiv = document.getElementById("result");

  if (!host) {
    resultDiv.innerText = "❌ Host kosong.";
    return;
  }

  resultDiv.innerText = "⏳ Sedang melakukan ping...";

  fetch(`/api/ping?host=${host}`)
    .then(res => res.json())
    .then(data => {
      if (data.alive) {
        resultDiv.innerText = `✅ ${data.host} aktif. Latency: ${data.time} ms`;
      } else {
        resultDiv.innerText = `❌ ${data.host} tidak merespons.`;
      }
    });
}

function cekStatusSuperPing() {
  const host = document.getElementById("hostInput").value;
  const resultDiv = document.getElementById("result");

  if (!host) {
    resultDiv.innerText = "❌ Host kosong.";
    return;
  }

  resultDiv.innerText = "⏳ Menghubungi SuperPing...";

  fetch(`/api/superping?host=${host}`)
    .then(res => res.json())
    .then(data => {
      if (data.status) {
        resultDiv.innerText = `🌐 SuperPing:
- Status: ${data.status}
- Latency: ${data.latency} ms
- Lokasi: ${data.location}`;
      } else {
        resultDiv.innerText = "⚠️ Tidak ada data dari SuperPing.";
      }
    });
}
